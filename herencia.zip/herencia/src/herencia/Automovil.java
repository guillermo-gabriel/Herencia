package herencia;
             
public class Automovil extends Vehiculo {
        
	private int noPasajero;
	
	public Automovil(String numPlaca,String Color,String Modelo,int nPas) {
		super(numPlaca,Color,Modelo);
		this.noPasajero=nPas;
	}
	public int getNoPasajero() {
		return noPasajero;
	}
	public void setNoPasajero(int noPasajero) {
		this.noPasajero = noPasajero;
	}
	public void ModoManejo() {
		System.out.println("Auto en modo Manejor :Sports");
	}
}
