package herencia;

public class Principal {

	public static void main(String[] args) {

		Automovil auto=new Automovil ("AVH-765","ROJO","sUSUKI",5);
		System.out.println(auto.getColor()+" "+auto.getModelo()+" "+auto.getNoPasajero()+" "+auto.getNumPlaca());
		auto.ModoManejo();
		auto.Acelerar();
		auto.CambiarVelocidad();
		auto.Frenar();

	}
	
}
