package herencia;

public class Vehiculo {

private String numPlaca;
private String Color;
private String Modelo;

public Vehiculo(String numPlaca,String Color , String Modelo ) {
	
this.numPlaca=numPlaca;
this.Color=Color;
this.Modelo=Modelo;
}
	
public String getNumPlaca() {
	return numPlaca;
}

public void setNumPlaca(String numPlaca) {
	this.numPlaca = numPlaca;
}

public String getColor() {
	return Color;
}

public void setColor(String color) {
	Color = color;
}

public String getModelo() {
	return Modelo;
}

public void setModelo(String modelo) {
	Modelo = modelo;
}

public void Acelerar() {
	
	System.out.println("Este vehiculo esta: Avanzado");
}
public void Frenar() {
	
	System.out.println("Este vehiculo esta: Frenando");
}
public void CambiarVelocidad() {
	
	System.out.println("Este vehiculo esta: Calmbiando velocidad");
}

}
